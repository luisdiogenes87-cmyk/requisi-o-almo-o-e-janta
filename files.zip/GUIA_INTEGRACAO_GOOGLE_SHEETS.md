# 📋 GUIA COMPLETO - Integração com Google Sheets

## Passo 1️⃣: Criar uma Planilha no Google Sheets

1. Acesse **Google Drive** (drive.google.com)
2. Clique em **"+ Novo"** → **Google Sheets**
3. Nomeie como: **"Pedidos de Refeição"**
4. A planilha será criada automaticamente com uma aba chamada **"Planilha sem título"**
5. **Renomeie a aba para "Pedidos"** (clique direito na aba → Renomear)

### Copiar o ID da Planilha
- A URL da sua planilha será algo assim:
  ```
  https://docs.google.com/spreadsheets/d/1kB8rR5zKfV2hJ1m3nP7qL9sT4uV6wX8y/edit
  ```
- **Copie a parte destacada** (entre `/d/` e `/edit`):
  ```
  1kB8rR5zKfV2hJ1m3nP7qL9sT4uV6wX8y
  ```
- Você usará isso no Script do Google Apps

---

## Passo 2️⃣: Criar o Google Apps Script

1. Acesse **Google Drive**
2. Clique em **"+ Novo"** → **Mais** → **Google Apps Script**
3. Uma nova aba será aberta com um editor
4. **Apague todo o código** que já está lá
5. **Cole o código abaixo:**

```javascript
// ============================================================
// GOOGLE APPS SCRIPT - Integração com Google Sheets
// ============================================================

// COLE AQUI SEU ID DA PLANILHA
const SHEET_ID = "1kB8rR5zKfV2hJ1m3nP7qL9sT4uV6wX8y";
const SHEET_NAME = "Pedidos";

/**
 * Função principal que recebe os dados POST
 */
function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);

    if (!data) {
      return ContentService
        .createTextOutput(JSON.stringify({
          success: false,
          message: "Dados não recebidos"
        }))
        .setMimeType(ContentService.MimeType.JSON);
    }

    const ss = SpreadsheetApp.openById(SHEET_ID);
    const sheet = ss.getSheetByName(SHEET_NAME);

    if (sheet.getLastRow() === 0) {
      criarCabecalho(sheet);
    }

    const novaLinha = [
      new Date().toLocaleString('pt-BR'),
      data.nome || '',
      data.equipe || '',
      data.data || '',
      data.local || '',
      data.tipo || '',
      data.motivo || '',
      data.valor || '',
      data.observacao || '',
      'Pendente'
    ];

    sheet.appendRow(novaLinha);

    return ContentService
      .createTextOutput(JSON.stringify({
        success: true,
        message: "Pedido registrado com sucesso na planilha!",
        timestamp: new Date().toLocaleString('pt-BR')
      }))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (error) {
    return ContentService
      .createTextOutput(JSON.stringify({
        success: false,
        message: "Erro ao registrar pedido: " + error.toString()
      }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

/**
 * Criar cabeçalho da planilha
 */
function criarCabecalho(sheet) {
  const cabecalho = [
    "Timestamp",
    "Nome",
    "Equipe",
    "Data do Serviço",
    "Local",
    "Tipo de Refeição",
    "Motivo",
    "Valor (R$)",
    "Observação",
    "Status"
  ];

  sheet.appendRow(cabecalho);

  const headerRange = sheet.getRange(1, 1, 1, cabecalho.length);
  headerRange.setBackground("#2c3e50");
  headerRange.setFontColor("white");
  headerRange.setFontWeight("bold");

  sheet.setFrozenRows(1);
}

/**
 * Função para testar
 */
function testarIntegracao() {
  const dadosTeste = {
    nome: "TESTE USER",
    equipe: "SST & Engineering",
    data: "2025-01-29",
    local: "Campo",
    tipo: "Almoço",
    motivo: "Serviço em campo",
    valor: "45,00",
    observacao: "Pedido de teste",
    timestamp: new Date().toLocaleString('pt-BR')
  };

  const e = {
    postData: {
      contents: JSON.stringify(dadosTeste)
    }
  };

  const resultado = doPost(e);
  Logger.log("Resultado do teste: " + resultado.getContent());
}
```

6. **⚠️ IMPORTANTE**: Substitua `"1kB8rR5zKfV2hJ1m3nP7qL9sT4uV6wX8y"` pelo ID da sua planilha (do Passo 1)
7. Clique em **"Salvar"** (Ctrl+S)

---

## Passo 3️⃣: Fazer o Deploy do Script

1. Clique em **"Deploy"** (canto superior direito)
2. Clique em **"New Deployment"** (ou "Novo Deploy")
3. Clique no ícone de engrenagem **"Select type"**
4. Escolha **"Web app"**
5. Preencha os campos:
   - **Execute as:** Seu email do Google
   - **Who has access:** "Anyone"
6. Clique em **"Deploy"**
7. Será solicitada **permissão** - clique em **"Allow"** (Autorizar)
8. Uma nova janela aparecerá com a URL do deployment

### Copiar a URL do Deployment
- Você verá algo assim:
  ```
  https://script.google.com/macros/d/1kB8rR5zKfV2hJ1m3nP7qL9sT4uV6wX8y/usercallback
  ```
- **Copie essa URL completa** (você usará no formulário HTML)

---

## Passo 4️⃣: Configurar o Formulário HTML

1. Abra o arquivo **`sistema_refeicoes_integrado.html`**
2. Procure por esta linha (aproximadamente na linha 360):
   ```javascript
   const GOOGLE_APPS_SCRIPT_URL = "https://script.google.com/macros/d/SEU_SCRIPT_ID/usercallback";
   ```

3. Substitua `"https://script.google.com/macros/d/SEU_SCRIPT_ID/usercallback"` pela URL do deployment que você copiou no Passo 3

4. **Exemplo completo:**
   ```javascript
   const GOOGLE_APPS_SCRIPT_URL = "https://script.google.com/macros/d/1kB8rR5zKfV2hJ1m3nP7qL9sT4uV6wX8y/usercallback";
   ```

5. Salve o arquivo (Ctrl+S)

---

## Passo 5️⃣: Testar a Integração

1. **Abra o arquivo HTML** no navegador
2. **Preencha o formulário** normalmente
3. Clique em **"Enviar Pedido"**
4. Você verá uma mensagem: **"✅ Pedido registrado com sucesso!"**
5. **Volte para a planilha do Google Sheets** e recarregue (F5)
6. Os dados devem aparecer como uma nova linha!

---

## 🎯 Fluxo de Dados Resumido

```
Formulário HTML
      ↓
   (Validação)
      ↓
JSON enviado para Google Apps Script
      ↓
   (doPost Function)
      ↓
Escrita no Google Sheets
      ↓
Mensagem de sucesso
```

---

## ⚠️ Possíveis Erros

### ❌ "URL do Google Apps Script não configurada"
- **Solução**: Você não copiou a URL do deployment na linha 360 do HTML
- Volte ao Passo 4 e verifique

### ❌ "Erro ao enviar pedido"
- **Solução**: Abra o console (F12 → Aba Console) e veja a mensagem de erro
- Verifique se o ID da planilha está correto no Script

### ❌ Dados não aparecem na planilha
- **Solução**: Verifique se a aba se chama **"Pedidos"** (case-sensitive)
- Recarregue a planilha (F5)

---

## 📊 Visualizar Dados na Planilha

Após registrar alguns pedidos, você pode:

1. **Adicionar filtros** para organizar por equipe, data, tipo de refeição
2. **Criar gráficos** para visualizar gastos com refeições
3. **Usar fórmulas** para somar valores por período
4. **Compartilhar** com o gerente para revisão

### Exemplo de Fórmula para Total do Dia:
```
=SUMIFS(H:H, A:A, ">="&DATE(2025,1,29), A:A, "<"&DATE(2025,1,30))
```

---

## 🔒 Segurança

- ✅ O script valida se os dados foram recebidos
- ✅ Os dados são gravados em ordem de recebimento
- ✅ A planilha pode ser compartilhada apenas com quem precisa
- ✅ O formulário pode ser hospedado internamente na intranet

---

## 📱 Funcionalidades Extras (Opcional)

Você pode adicionar:

1. **Notificação por email** ao registrar pedido
2. **Geração de PDF** para impressão
3. **Dashboard com gráficos** dos gastos
4. **Integração com Slack** para avisar o operacional
5. **Campos dinâmicos** que vêm da própria planilha

---

## 📞 Resumo dos IDs que você precisa

| Informação | Onde encontra | Onde usa |
|-----------|--------------|---------|
| **ID da Planilha** | URL do Sheets (entre /d/ e /edit) | Linha 2 do Script do Apps |
| **URL do Deploy** | Após fazer deploy do Apps Script | Linha 360 do HTML |
| **Nome da Aba** | Abas na planilha | Linha 3 do Script do Apps |

---

**Dúvidas? Tente novamente seguindo cada passo! 🚀**
